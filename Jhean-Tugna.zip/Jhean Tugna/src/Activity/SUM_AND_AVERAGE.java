package Activity;
import java.util.Scanner;
public class SUM_AND_AVERAGE {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int n;
        n = 10; 
        int[] arrInts = new int[n];
        int sum = 0;

        System.out.println("\nSUM AND AVERAGE");
        System.out.printf("input 10 integers to be stored in an array: ");
        for (int i = 0; i < n; i++) {
            arrInts[i] = input.nextInt(); // get integer number
            sum = sum + arrInts[i]; // add them all to sum
        }

        int avg = sum / n; // get the average 
        System.out.printf("sum of integers: %d and it's average: %d",
                sum, avg);
        System.out.println("\t");
    }
}
